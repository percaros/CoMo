#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>

// --- Credenciales WiFi ---
const char* ssid     = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// --- IP estática ---
IPAddress local_IP(172, 31, 0, 111);
IPAddress gateway(172, 31, 0, 1);
IPAddress subnet(255, 255, 255, 0);

// --- Servidor HTTP ---
ESP8266WebServer server(80);

// --- Pines de relés ---
#define RELAY_ON   1
#define RELAY_OFF  0

bool servidorIniciado    = false;
bool relesPorFalloWiFi   = false;
int  lastState           = RELAY_OFF;

void setRelays(int estado) {
  digitalWrite(D1, estado ? RELAY_ON : RELAY_OFF);
  digitalWrite(D5, estado ? RELAY_ON : RELAY_OFF);
  digitalWrite(D6, estado ? RELAY_ON : RELAY_OFF);
  digitalWrite(D7, estado ? RELAY_ON : RELAY_OFF);
}

void activarRelesPorDefecto() {
  setRelays(1);
  Serial.println("WiFi no disponible → relés ACTIVADOS (fallback).");
  relesPorFalloWiFi = true;
}

void manejarActivacion() {
  Serial.println("==> /activar INVOCADO");
  if (!server.hasArg("activacion")) {
    Serial.println("   ✖ falta arg ‘activacion’");
    server.send(400, "text/plain", "Falta argumento 'activacion'");
    return;
  }

  int estado = server.arg("activacion").toInt();
  Serial.printf("   • activacion = %d\n", estado);

  setRelays(estado);
  lastState        = estado;
  relesPorFalloWiFi = false;
  Serial.println( estado ? "   ✔ Relés ACTIVADOS" : "   ✔ Relés DESACTIVADOS" );

  // Forzar cierre del socket para evitar arrastrar conexiones viejas
  server.sendHeader("Connection", "close");
  server.send(200, "text/plain", "Recibido");
}

void setup() {
  Serial.begin(115200);
  pinMode(D1, OUTPUT);
  pinMode(D5, OUTPUT);
  pinMode(D6, OUTPUT);
  pinMode(D7, OUTPUT);
  setRelays(RELAY_OFF);

  // 1) Habilitar reconexión automática y persistencia
  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);

  // 2) Configurar IP estática
  WiFi.config(local_IP, gateway, subnet);

  // 3) Iniciar conexión WiFi
  WiFi.begin(ssid, password);
  Serial.print("Conectando a WiFi");
  unsigned long inicio = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - inicio < 10000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  // 4) Registrar ruta HTTP UNA sola vez
  server.on("/activar", manejarActivacion);

  // 5) Arrancar servidor o activar fallback
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("→ Conectado. IP: " + WiFi.localIP().toString());
    server.begin();
    servidorIniciado = true;
    Serial.println("Servidor HTTP iniciado");
  } else {
    Serial.println("! No conectado en setup. Activando fallback.");
    activarRelesPorDefecto();
  }
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    // Al reconectar, arrancar servidor y restaurar relés UNA sola vez
    if (!servidorIniciado) {
      Serial.println("WiFi reconectado → iniciando servidor...");
      server.begin();
      servidorIniciado = true;
      if (relesPorFalloWiFi) {
        setRelays(lastState);
        relesPorFalloWiFi = false;
        Serial.println("Restaurado último estado de relés");
      }
    }
    server.handleClient();
  }
  else {
    // Fallback: relés ON mientras no hay WiFi
    if (!relesPorFalloWiFi) {
      activarRelesPorDefecto();
    }
    // Reintento cada 5 s
    static unsigned long ultimoIntento = 0;
    if (millis() - ultimoIntento > 5000) {
      Serial.println("WiFi desconectado → reintentando conexión...");
      WiFi.reconnect();
      ultimoIntento = millis();
      servidorIniciado = false;  // forzar re-inicio del servidor al recobrar WiFi
    }
    // Ceder tiempo al stack de WiFi
    delay(1);
  }
}
